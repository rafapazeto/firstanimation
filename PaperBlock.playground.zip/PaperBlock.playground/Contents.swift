//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .lightGray
        
        self.view = view
        let paperView = UIImageView()
        paperView.image = UIImage(named: "paper.jpg")
        paperView.frame = CGRect(x: 0, y: 35, width: 400, height: 600)
        paperView.contentMode = .scaleAspectFit
        view.addSubview(paperView)
        
        let smileView = UIImageView()
         smileView.image = UIImage(named: "smileyFace.png")
         smileView.frame = CGRect(x: 25, y: 250, width: 150, height: 150)
         smileView.contentMode = .scaleAspectFit
        smileView.transform = CGAffineTransform(rotationAngle: -25 * .pi/180)
        smileView.alpha = 0
         view.addSubview(smileView)
        
        let smiledView = UIImageView()
         smiledView.image = UIImage(named: "smiled.png")
         smiledView.frame = CGRect(x: 25, y: 250, width: 150, height: 150)
         smiledView.contentMode = .scaleAspectFit
        smiledView.transform = CGAffineTransform(rotationAngle: -25 * .pi/180)
        smiledView.alpha = 0
         view.addSubview(smiledView)
        
        let confusedView = UIImageView()
         confusedView.image = UIImage(named: "confused.png")
         confusedView.frame = CGRect(x: 25, y: 250, width: 150, height: 150)
         confusedView.contentMode = .scaleAspectFit
        confusedView.transform = CGAffineTransform(rotationAngle: -25 * .pi/180)
        confusedView.alpha = 0
         view.addSubview(confusedView)
        
        let handView = UIImageView()
        handView.image = UIImage(named: "hand.png")
        handView.frame = CGRect(x: 30, y: 200, width: 250, height: 250)
        handView.contentMode = .scaleAspectFit
        view.addSubview(handView)
        
        UIView.animate(withDuration: 1.5, animations: {
            handView.frame = CGRect(x: 15, y: 230, width: 250, height: 250)
        }) { (true) in
            UIView.animate(withDuration: 1.5, animations: {
                handView.frame = CGRect(x: 10, y: 210, width: 250, height: 250)
            }) { (true) in
                UIView.animate(withDuration: 1.5, animations: {
                    handView.frame = CGRect(x: 30, y: 200, width: 250, height: 250)
                }) { (true) in
                    UIView.animate(withDuration: 1.5, animations: {
                        handView.frame = CGRect(x: 10, y: 130, width: 250, height: 250)
                        smileView.alpha = 1
                    }) { (true) in
                        UIView.animate(withDuration: 2.5, animations: {
                            handView.frame = CGRect(x: 10, y: 250, width: 250, height: 250)
                            smileView.alpha = 0
                            smiledView.alpha = 1
                        }) { (true) in
                            UIView.animate(withDuration: 1.5, animations: {
                                handView.frame = CGRect(x: 70, y: 280, width: 250, height: 250)
                                smiledView.alpha = 0
                                confusedView.alpha = 1
                            }) { (true) in
                            }
                        }
                    }
                }
            }
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
